import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'

function App() {
  return (
    <div className="max-w-xl mx-auto mt-10 p-4 bg-white shadow-lg rounded-lg">
      <h1 className="text-2xl font-bold mb-4">欢迎来到 Aplysia 海兔 🐇</h1>
      <div className="space-y-4">
        <div className="p-4 border rounded-md">
          <p>🚗 找拼车：4月15日 从纽约去波士顿，2人空位</p>
        </div>
        <div className="p-4 border rounded-md">
          <p>🏠 找房源：巴黎市中心单间出租，短租可谈</p>
        </div>
        <div className="p-4 border rounded-md">
          <p>🍜 华人美食推荐：多伦多最强拉面店！</p>
        </div>
      </div>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
